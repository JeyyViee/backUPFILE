import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Image, Alert, ActivityIndicator, ScrollView, Modal } from 'react-native';
import { firebase } from '../firebaseUserConfig';
import { collection, addDoc, getDoc, doc } from 'firebase/firestore';
import { getAuth } from 'firebase/auth';
import * as ImagePicker from 'expo-image-picker';
import DocumentPicker from 'react-native-document-picker';
import { getStorage, ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { Picker } from '@react-native-picker/picker';
import RNFS from 'react-native-fs';



const ServiceProduct = ({ navigation }) => {
  const [name, setName] = useState('');
  const [price, setPrice] = useState('');
  const [sellerName, setSellerName] = useState('');
  const [imageUri, setImageUri] = useState(null);
  const [imageUris, setImageUris] = useState([]); // For multi-image showcase
  const [uploading, setUploading] = useState(false);
  const [imageUploading, setImageUploading] = useState(false);
  const [type, setType] = useState('product');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('');
  const [terms, setTerms] = useState('');
  const [selectedFile, setSelectedFile] = useState(null); // Store selected file
  const [fileName, setFileName] = useState(''); // Store file name for preview
  const [selectedVideo, setSelectedVideo] = useState(null); // Store selected video
  const [videoName, setVideoName] = useState(''); // Store video name for preview
  const [selectedMusic, setSelectedMusic] = useState(null); // Store selected music
  const [musicName, setMusicName] = useState(''); // Store music name for preview
  const [selectedFiles, setSelectedFiles] = useState([]); // For files
  const [selectedImages, setSelectedImages] = useState([]); // For images
  const [selectedAudio, setSelectedAudio] = useState([]); // For audio
  const [selectedOthers, setSelectedOthers] = useState([]); // For others  
  const [isPreviewVisible, setPreviewVisible] = useState(false); // Controls preview modal
  const [previewCategory, setPreviewCategory] = useState(null); // Category being previewed
  


  const user = getAuth().currentUser;
  const MAX_IMAGES = 5;

  // Fetch the user's first and last name
  const fetchUserDetails = async (uid) => {
    try {
      const userDoc = await getDoc(doc(firebase.firestore(), 'users', uid));
      if (userDoc.exists()) {
        const userData = userDoc.data();
        const fullName = `${userData.firstName || ''} ${userData.lastName || ''}`.trim();
        setSellerName(fullName || 'Anonymous');
      } else {
        console.log('User document does not exist');
        setSellerName('Anonymous');
      }
    } catch (error) {
      console.error('Error fetching user details: ', error);
      setSellerName('Anonymous');
    }
  };

  if (user) {
      fetchUserDetails(user.uid);
    }

  useEffect(() => {
    return () => {
    };
  }, [user]);

  

  // For banner-style image
  const handleImagePick = async () => {
    const permissionResult = await ImagePicker.requestMediaLibraryPermissionsAsync();

    if (permissionResult.granted === false) {
      Alert.alert("Permission to access the media library is required!");
      return;
    }

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [16, 9], // Banner aspect ratio
      quality: 1,
    });

    if (!result.canceled) {
      setImageUri(result.assets[0].uri);
    }
  };

  const handleFilePick = async () => {
    try {
      const result = await DocumentPicker.pick({
        type: [DocumentPicker.types.allFiles],
        allowsMultipleSelection: true,
      });

      if (result[0] && result[0].uri) {
        setSelectedFile(result[0]); // Save the selected file
        setFileName(result[0].name); // Display the name of the file
      } else {
        Alert.alert('File URI not found. Please try selecting another file.');
      }
    } catch (err) {
      if (DocumentPicker.isCancel(err)) {
        // User cancelled the picker
      } else {
        console.error('Unknown error while picking file:', err);
      }
    }
  };

  // Document-Specific File Picker
  const handleDocumentPick = async () => {
    try {
      const result = await DocumentPicker.pick({
        type: [DocumentPicker.types.pdf, DocumentPicker.types.plainText, DocumentPicker.types.doc, DocumentPicker.types.docx], // Accept specific document types
        allowsMultipleSelection: false, // Set to true if you want to allow multiple files
      });

      if (result[0] && result[0].uri) {
        setSelectedFile(result[0]); // Save the selected document
        setFileName(result[0].name); // Display the name of the document
      } else {
        Alert.alert('Document URI not found. Please try selecting another document.');
      }
    } catch (err) {
      if (DocumentPicker.isCancel(err)) {
        // User cancelled the picker
        Alert.alert('Document selection canceled.');
      } else {
        console.error('Unknown error while picking document:', err);
      }
    }
  };


  const handleVideoPick = async () => {
    try {
      const result = await DocumentPicker.pick({
        type: [DocumentPicker.types.video], // Only videos
        allowsMultipleSelection: true,
      });

      if (result[0] && result[0].uri) {
        setSelectedVideo(result[0]); // Save the selected video
        setVideoName(result[0].name); // Display the name of the video
      } else {
        Alert.alert('Video URI not found. Please try selecting another video.');
      }
    } catch (err) {
      if (DocumentPicker.isCancel(err)) {
        // User cancelled the picker
      } else {
        console.error('Unknown error while picking video:', err);
      }
    }
  };

  const handleMusicPick = async () => {
    try {
      const result = await DocumentPicker.pick({
        type: [DocumentPicker.types.audio], // Only audio files
        allowsMultipleSelection: true,
      });

      if (result[0] && result[0].uri) {
        setSelectedMusic(result[0]); // Save the selected music
        setMusicName(result[0].name); // Display the name of the music
      } else {
        Alert.alert('Music URI not found. Please try selecting another audio file.');
      }
    } catch (err) {
      if (DocumentPicker.isCancel(err)) {
        // User cancelled the picker
      } else {
        console.error('Unknown error while picking music:', err);
      }
    }
  };

  // Multi-image picker for image showcase
  const handlePickImages = async () => {
    const permissionResult = await ImagePicker.requestMediaLibraryPermissionsAsync();

    if (!permissionResult.granted) {
      Alert.alert("Permission to access the media library is required!");
      return;
    }

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsMultipleSelection: true,
      quality: 1,
    });

   if (!result.canceled && result.assets && result.assets.length > 0) {
    if (result.assets.length <= MAX_IMAGES) {
      const selectedImages = result.assets.map(asset => asset.uri);
      setImageUris(selectedImages);
    } else {
      Alert.alert(`You can only select up to ${MAX_IMAGES} images.`);
    }
  } else {
    console.log('Image picking was canceled or no images were selected.');
  }
  };

  // Upload Document to Firebase Storage
  const uploadDocumentToStorage = async () => {
    if (!selectedFile) return null; // No file to upload

    try {
      setUploading(true);
      const storage = getStorage();
      const fileRef = ref(storage, `documents/${Date.now()}_${selectedFile.name}`);

      // Read document file using react-native-fs
      const filePath = selectedFile.uri;
      const fileData = await RNFS.readFile(filePath, 'base64'); // Read file as base64 encoded string

      // Convert base64 string into a Blob (Firebase requires a Blob/File object)
      const blob = new Blob([fileData], { type: selectedFile.mimeType });

      // Upload document
      const uploadResult = await uploadBytes(fileRef, blob);

      // Get download URL after upload
      return await getDownloadURL(uploadResult.ref);
    } catch (error) {
      console.error('Error uploading document:', error);
      return null;
    } finally {
      setUploading(false);
    }
  };

  // Upload both single banner image and multiple showcase images
  const uploadImagesToStorage = async () => {
    const storage = getStorage();
    setUploading(true);
    const uploadedUrls = [];

    for (let i = 0; i < imageUris.length; i++) {
      try {
        const response = await fetch(imageUris[i]);
        const blob = await response.blob();

        const imageRef = ref(storage, `products_services/multiple/${Date.now()}_image${i}.jpg`);
        const uploadResult = await uploadBytes(imageRef, blob);

        const downloadUrl = await getDownloadURL(uploadResult.ref);
        uploadedUrls.push(downloadUrl);
      } catch (error) {
        console.error('Error uploading image:', error);
      }
    }

    setUploading(false);
    return uploadedUrls;
  };

  const uploadFileToStorage = async () => {
      if (!selectedFile) return null; // No file to upload

      try {
        setUploading(true);
        const storage = getStorage();
        const fileRef = ref(storage, `documents/${Date.now()}_${selectedFile.name}`);
        
        // Read file using react-native-fs
        const filePath = selectedFile.uri;
        const fileData = await RNFS.readFile(filePath, 'base64'); // Read file as base64 encoded string
        
        // Convert base64 string into a Blob (Firebase requires a Blob/File object)
        const blob = new Blob([fileData], { type: selectedFile.type });

        // Upload file
        const uploadResult = await uploadBytes(fileRef, blob);

        // Get download URL after upload
        return await getDownloadURL(uploadResult.ref);
      } catch (error) {
        console.error('Error uploading file:', error);
        return null;
      } finally {
        setUploading(false);
      }
    };

  const uploadVideoToStorage = async () => {
    if (!selectedVideo) return null; // No video to upload

    try {
      setUploading(true);
      const storage = getStorage();
      const videoRef = ref(storage, `videos/${Date.now()}_${selectedVideo.name}`);

      const filePath = selectedVideo.uri;
      const fileData = await RNFS.readFile(filePath, 'base64'); // Read file as base64

      const blob = new Blob([fileData], { type: selectedVideo.type });

      const uploadResult = await uploadBytes(videoRef, blob);
      return await getDownloadURL(uploadResult.ref);
    } catch (error) {
      console.error('Error uploading video:', error);
      return null;
    } finally {
      setUploading(false);
    }
  };

  const uploadMusicToStorage = async () => {
    if (!selectedMusic) return null; // No music to upload

    try {
      setUploading(true);
      const storage = getStorage();
      const musicRef = ref(storage, `music/${Date.now()}_${selectedMusic.name}`);

      const filePath = selectedMusic.uri;
      const fileData = await RNFS.readFile(filePath, 'base64'); // Read file as base64

      const blob = new Blob([fileData], { type: selectedMusic.type });

      const uploadResult = await uploadBytes(musicRef, blob);
      return await getDownloadURL(uploadResult.ref);
    } catch (error) {
      console.error('Error uploading music:', error);
      return null;
    } finally {
      setUploading(false);
    }
  };


  const uploadBannerImageToStorage = async () => {
    if (!imageUri) return null;

    try {
      setImageUploading(true);
      const storage = getStorage(); // Ensure storage is initialized correctly
      const imageRef = ref(storage, `services_products/${Date.now()}_${user.uid}.jpg`);
      const response = await fetch(imageUri);
      const blob = await response.blob();

      // Upload image
      const uploadResult = await uploadBytes(imageRef, blob);

      // Get download URL after upload
      return await getDownloadURL(uploadResult.ref);
    } catch (error) {
      console.error('Error uploading image:', error);
      return null;
    } finally {
      setImageUploading(false);
    }
  };

    // Show the preview for a category
  const showPreview = (category) => {
    setPreviewCategory(category);
    setPreviewVisible(true);
  };

  // Clear files for the specific category
  const clearFiles = () => {
    if (previewCategory === 'file') {
      setSelectedFile(null);
      setFileName('');
    } else if (previewCategory === 'video') {
      setSelectedVideo(null);
      setVideoName('');
    } else if (previewCategory === 'music') {
      setSelectedMusic(null);
      setMusicName('');
    } else if (previewCategory === 'images') {
      setImageUris([]);
    }

    setPreviewVisible(false); // Close modal after clearing
  };

  const handleAddProduct = async () => {
    if (!name || !price || !description || !category) {
      Alert.alert('Please fill all required fields!');
      return;
    }

    setUploading(true); // Set uploading state to true when process starts

        const parsedPrice = parseFloat(price);
    
    if (isNaN(parsedPrice)) {
      Alert.alert('Please enter a valid price!');
      return;
    }

    // Multiply the parsed price by 100 to handle cents (e.g., 10.25 becomes 1025)
    const formattedPrice = Math.round(parsedPrice * 100);

    const imageUrl = await uploadBannerImageToStorage(); // Upload banner image
    if (!imageUrl) {
      Alert.alert('Failed to upload image. Please try again.');
      setUploading(false); // Ensure loading is stopped if there's an error
      return;
    }
    const uploadedImageUrls = await uploadImagesToStorage(); // Upload multiple images

    let fileUrl = null;
    let videoUrl = null;
    let musicUrl = null;
    let documentUrl = null;


  if (category === 'file') {
    fileUrl = await uploadFileToStorage(); // Upload file
    if (!fileUrl) {
      Alert.alert('Failed to upload file. Please try again.');
      setUploading(false);
      return;
    }
  }

  // Upload the document if the 'file' category is selected
  if (category === 'file') {
    documentUrl = await uploadDocumentToStorage();
    if (!documentUrl) {
      Alert.alert('Failed to upload document. Please try again.');
      setUploading(false);
      return;
    }
  }

  if (category === 'video') {
    videoUrl = await uploadVideoToStorage();
    if (!videoUrl) {
      Alert.alert('Failed to upload video. Please try again.');
      return;
    }
  }

  if (category === 'music') {
    musicUrl = await uploadMusicToStorage();
    if (!musicUrl) {
      Alert.alert('Failed to upload music. Please try again.');
      return;
    }
  }

    try {
      await addDoc(collection(firebase.firestore(), 'products_services'), {
        name,
        price: formattedPrice,
        uid: user.uid,
        sellerName,
        imageUrl, // Banner image URL
        images: uploadedImageUrls, // Multiple showcase images URLs
        description,
        fileUrl,
        documentUrl,
        videoUrl,
        musicUrl,
        type,
        category,
        terms: type === 'service' ? terms : null,
        createdAt: firebase.firestore.FieldValue.serverTimestamp(),
      });
      Alert.alert('Product/Service added successfully!');
      navigation.navigate('SellerPosting');
    } catch (error) {
      console.error('Error adding product:', error);
      Alert.alert('Failed to add product. Please try again.');
    } finally {
      setUploading(false); // Stop the loader
    }
  };


return (
  <ScrollView contentContainerStyle={styles.scrollContainer}>
    <View style={styles.container}>
      <Text style={styles.title}>Add New Product/Service</Text>

      {/* Name and Price Inputs */}
      <TextInput
        style={styles.input}
        placeholder="Product/Service Name (max 100 chars)"
        value={name}
        onChangeText={(text) => {
          if (text.length <= 100) setName(text);
          else Alert.alert('Name must be 100 characters or less!');
        }}
        maxLength={100}
      />

      <TextInput
        style={styles.input}
        placeholder="Price (in dollars)"
        value={price}
        keyboardType="numeric"
        onChangeText={(text) => {
          const numericValue = text.replace(/[^0-9.]/g, '');
          const parts = numericValue.split('.');
          if (parts.length > 2) {
            return;
          }

          if (parts.length === 2 && parts[1].length > 2) {
            return;
          }

          setPrice(numericValue); // Set the price without formatting
        }}
      />

      {/* Type and Description Inputs */}
      <Picker selectedValue={type} onValueChange={setType} style={styles.picker}>
        <Picker.Item label="Product" value="product" />
        <Picker.Item label="Service" value="service" />
      </Picker>

      <TextInput
        style={styles.input}
        placeholder="Description (max 2000 characters)"
        value={description}
        onChangeText={setDescription}
        maxLength={2000}
        multiline
      />

      {type === 'service' && (
        <TextInput
          style={styles.input}
          placeholder="Terms of Service (max 2000 characters)"
          value={terms}
          onChangeText={setTerms}
          maxLength={2000}
          multiline
        />
      )}

      {/* Banner Image Picker */}
      <TouchableOpacity onPress={handleImagePick} style={styles.imageButton}>
        <Text style={styles.imageButtonText}>Pick Banner Image</Text>
      </TouchableOpacity>

      {imageUri && (
        <Image source={{ uri: imageUri }} style={{ width: '100%', height: 200 }} />
      )}

      {/* Category Picker */}
      <Picker selectedValue={category} onValueChange={setCategory} style={styles.picker}>
        <Picker.Item label="Select Category" value="" />
        <Picker.Item label="Images" value="images" />
        <Picker.Item label="File" value="file" />
        <Picker.Item label="Video" value="video" />
        <Picker.Item label="Music" value="music" />
        <Picker.Item label="Others" value="others" />
      </Picker>

      {/* Conditional Uploaders based on Category */}
      {category === 'images' && (
        <>
          <Text style={styles.sectionTitle}>Upload Multiple Images</Text>
          <TouchableOpacity style={styles.imageButton} onPress={handlePickImages}>
            <Text style={styles.imageButtonText}>Pick Images (Max 5)</Text>
          </TouchableOpacity>

          <View style={styles.imagePreviewContainer}>
            {imageUris.map((uri, index) => (
              <Image key={index} source={{ uri }} style={styles.imagePreview} />
            ))}
          </View>
        </>
      )}

      {category === 'file' && (
        <>
          <Text style={styles.sectionTitle}>Upload a Document</Text>
          <TouchableOpacity style={styles.imageButton} onPress={handleDocumentPick}>
            <Text style={styles.imageButtonText}>Pick a Document</Text>
          </TouchableOpacity>
          {fileName ? (
            <Text style={styles.filePreviewText}>Selected Document: {fileName}</Text>
          ) : (
            <Text style={styles.filePreviewText}>No document selected</Text>
          )}
        </>
      )}

      {category === 'video' && (
        <>
          <Text style={styles.sectionTitle}>Upload a Video</Text>
          <TouchableOpacity style={styles.imageButton} onPress={handleVideoPick}>
            <Text style={styles.imageButtonText}>Pick a Video</Text>
          </TouchableOpacity>
          {videoName ? (
            <Text style={styles.filePreviewText}>Selected Video: {videoName}</Text>
          ) : (
            <Text style={styles.filePreviewText}>No video selected</Text>
          )}
        </>
      )}

      {category === 'music' && (
        <>
          <Text style={styles.sectionTitle}>Upload a Music File</Text>
          <TouchableOpacity style={styles.imageButton} onPress={handleMusicPick}>
            <Text style={styles.imageButtonText}>Pick a Music File</Text>
          </TouchableOpacity>
          {musicName ? (
            <Text style={styles.filePreviewText}>Selected Music: {musicName}</Text>
          ) : (
            <Text style={styles.filePreviewText}>No music selected</Text>
          )}
        </>
      )}

      {category === 'others' && (
        <>
          <Text style={styles.sectionTitle}>Upload a File</Text>
          <TouchableOpacity style={styles.imageButton} onPress={handleFilePick}>
            <Text style={styles.imageButtonText}>Pick a File</Text>
          </TouchableOpacity>
          {fileName ? (
            <Text style={styles.filePreviewText}>Selected File: {fileName}</Text>
          ) : (
            <Text style={styles.filePreviewText}>No file selected</Text>
          )}
        </>
      )}

      {/* Preview Buttons */}
      <TouchableOpacity onPress={() => showPreview('file')}>
        <Text style={styles.previewButtonText}>Preview Files</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={() => showPreview('video')}>
        <Text style={styles.previewButtonText}>Preview Videos</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={() => showPreview('music')}>
        <Text style={styles.previewButtonText}>Preview Music</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={() => showPreview('images')}>
        <Text style={styles.previewButtonText}>Preview Images</Text>
      </TouchableOpacity>


    {isPreviewVisible && (
    <Modal
      visible={isPreviewVisible}
      animationType="slide"
      transparent={true}  // This makes the modal's backdrop transparent
      onRequestClose={() => setPreviewVisible(false)}
    >
      <View style={styles.modalContainer}>
        <View style={styles.modalContent}>
          {/* Add a background color here to avoid the content being transparent */}
          <Text style={{ color: '#000' }}>Preview {previewCategory}</Text>
          
          {/* Your conditional content based on category */}
          {previewCategory === 'file' && fileName ? <Text>{fileName}</Text> : null}
          {previewCategory === 'video' && videoName ? <Text>{videoName}</Text> : null}
          {previewCategory === 'music' && musicName ? <Text>{musicName}</Text> : null}
          {previewCategory === 'images' && imageUris.length > 0 ? (
          <ScrollView horizontal>
            {imageUris.map((uri, index) => (
              <Image
                key={index}
                source={{ uri }}
                style={styles.previewImage}
              />
            ))}
          </ScrollView>
        ) : null}


          <TouchableOpacity style={styles.clearButton} onPress={clearFiles}>
            <Text>Clear {previewCategory}</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.closeButton} onPress={() => setPreviewVisible(false)}>
            <Text>Close</Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
    )}


      {/* Save Product/Service */}
      {uploading ? (
        <ActivityIndicator size="large" color="#0000ff" />
      ) : (
        <TouchableOpacity style={styles.saveButton} onPress={handleAddProduct}>
          <Text style={styles.saveButtonText}>Save Product/Service</Text>
        </TouchableOpacity>
      )}
    </View>
  </ScrollView>
);
};

const styles = StyleSheet.create({
  scrollContainer: {
    flexGrow: 1,
    padding: 16,
  },
  container: {
    flex: 1,
    padding: 16,
    backgroundColor:'#fff',
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 16,
  },
    filePreviewText: {
    fontSize: 16,
    marginVertical: 8,
    color: '#333',
  },
  input: {
    height: 50,
    borderColor: '#ccc',
    borderWidth: 1,
    borderRadius: 8,
    paddingHorizontal: 10,
    marginBottom: 16,
  },
  picker: {
    height: 50,
    marginBottom: 16,
  },
  imageButton: {
    backgroundColor: '#007bff',
    padding: 10,
    borderRadius: 8,
    marginBottom: 16,
  },
  imageButtonText: {
    color: '#fff',
    textAlign: 'center',
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginVertical: 10,
  },
  imagePreviewContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
   previewContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginVertical: 5,
  },
  removeButton: {
    color: 'red',
    fontWeight: 'bold',
  },
  imagePreview: {
    width: 100,
    height: 100,
    marginVertical: 10,
    marginRight: 10,
    borderRadius: 8,
  },
  saveButton: {
    backgroundColor: '#28a745',
    padding: 16,
    borderRadius: 8,
    alignItems: 'center',
  },
  saveButtonText: {
    color: '#fff',
    fontWeight: 'bold',
  },
  button: {
    backgroundColor: '#007bff',
    padding: 15,
    borderRadius: 5,
    alignItems: 'center',
    marginBottom: 10,
  },
  buttonText: {
    color: '#fff',
    fontWeight: 'bold',
  },
  image: {
    width: '100%',
    height: 200,
    marginBottom: 10,
  },
  thumbnail: {
    width: 100,
    height: 100,
    marginRight: 10,
  },
  imageContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginBottom: 10,
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)' // semi-transparent background to dim the underlying content
  },
  modalContent: {
    width: '80%',
    padding: 20,
    backgroundColor: '#fff', // Opaque background for the modal content
    borderRadius: 10,
  },
  clearButton: {
    marginTop: 20,
  },
  closeButton: {
    marginTop: 10,
  },
  previewButtonText: {
    color: '#007BFF', // Change to your preferred color
    fontSize: 16,     // Adjust the font size
    fontWeight: 'bold', // Make text bold if needed
    textAlign: 'center', // Center the text
    paddingVertical: 10, // Add vertical padding
  },
  previewImage: {
    width: 100,  // Adjust width as needed
    height: 100, // Adjust height as needed
    marginRight: 10, // Adds spacing between images
    borderRadius: 10, // Optional: add rounded corners
  },
});

export default ServiceProduct
import React, { useState } from 'react';
import { View, Text, TouchableOpacity, Modal, Alert, StyleSheet } from 'react-native';
import DocumentPicker from 'react-native-document-picker';
import * as ImagePicker from 'expo-image-picker';

const MAX_IMAGES = 5; // Maximum number of images that can be selected

export default function FileUploader() {
  const [selectedFile, setSelectedFile] = useState(null);
  const [fileName, setFileName] = useState('');

  const [selectedVideo, setSelectedVideo] = useState(null);
  const [videoName, setVideoName] = useState('');

  const [selectedMusic, setSelectedMusic] = useState(null);
  const [musicName, setMusicName] = useState('');

  const [imageUris, setImageUris] = useState([]);

  const [isPreviewVisible, setPreviewVisible] = useState(false); // Preview modal state
  const [previewCategory, setPreviewCategory] = useState(null); // Tracks the category to preview

  // File Picker
  const handleFilePick = async () => {
    try {
      const result = await DocumentPicker.pick({
        type: [DocumentPicker.types.allFiles],
        allowsMultipleSelection: true,
      });

      if (result[0] && result[0].uri) {
        setSelectedFile(result[0]);
        setFileName(result[0].name);
      } else {
        Alert.alert('File URI not found. Please try selecting another file.');
      }
    } catch (err) {
      if (DocumentPicker.isCancel(err)) {
        Alert.alert('File selection canceled.');
      } else {
        console.error('Unknown error while picking file:', err);
      }
    }
  };

  // Document-Specific File Picker
  const handleDocumentPick = async () => {
    try {
      const result = await DocumentPicker.pick({
        type: [DocumentPicker.types.pdf, DocumentPicker.types.plainText, DocumentPicker.types.doc, DocumentPicker.types.docx],
        allowsMultipleSelection: false,
      });

      if (result[0] && result[0].uri) {
        setSelectedFile(result[0]);
        setFileName(result[0].name);
      } else {
        Alert.alert('Document URI not found. Please try selecting another document.');
      }
    } catch (err) {
      if (DocumentPicker.isCancel(err)) {
        Alert.alert('Document selection canceled.');
      } else {
        console.error('Unknown error while picking document:', err);
      }
    }
  };

  // Video Picker
  const handleVideoPick = async () => {
    try {
      const result = await DocumentPicker.pick({
        type: [DocumentPicker.types.video],
        allowsMultipleSelection: true,
      });

      if (result[0] && result[0].uri) {
        setSelectedVideo(result[0]);
        setVideoName(result[0].name);
      } else {
        Alert.alert('Video URI not found. Please try selecting another video.');
      }
    } catch (err) {
      if (DocumentPicker.isCancel(err)) {
        Alert.alert('Video selection canceled.');
      } else {
        console.error('Unknown error while picking video:', err);
      }
    }
  };

  // Music Picker
  const handleMusicPick = async () => {
    try {
      const result = await DocumentPicker.pick({
        type: [DocumentPicker.types.audio],
        allowsMultipleSelection: true,
      });

      if (result[0] && result[0].uri) {
        setSelectedMusic(result[0]);
        setMusicName(result[0].name);
      } else {
        Alert.alert('Music URI not found. Please try selecting another audio file.');
      }
    } catch (err) {
      if (DocumentPicker.isCancel(err)) {
        Alert.alert('Music selection canceled.');
      } else {
        console.error('Unknown error while picking music:', err);
      }
    }
  };

  // Multi-image picker for image showcase
  const handlePickImages = async () => {
    const permissionResult = await ImagePicker.requestMediaLibraryPermissionsAsync();

    if (!permissionResult.granted) {
      Alert.alert("Permission to access the media library is required!");
      return;
    }

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsMultipleSelection: true,
      quality: 1,
    });

    if (!result.canceled && result.assets && result.assets.length > 0) {
      if (result.assets.length <= MAX_IMAGES) {
        const selectedImages = result.assets.map(asset => asset.uri);
        setImageUris(selectedImages);
      } else {
        Alert.alert(`You can only select up to ${MAX_IMAGES} images.`);
      }
    } else {
      console.log('Image picking was canceled or no images were selected.');
    }
  };

  // Show the preview for a category
  const showPreview = (category) => {
    setPreviewCategory(category);
    setPreviewVisible(true);
  };

  // Clear files for the specific category
  const clearFiles = () => {
    if (previewCategory === 'file') {
      setSelectedFile(null);
      setFileName('');
    } else if (previewCategory === 'video') {
      setSelectedVideo(null);
      setVideoName('');
    } else if (previewCategory === 'music') {
      setSelectedMusic(null);
      setMusicName('');
    } else if (previewCategory === 'images') {
      setImageUris([]);
    }

    setPreviewVisible(false); // Close modal after clearing
  };

  return (
    <View>
      {/* Upload Buttons */}
      <TouchableOpacity onPress={handleFilePick}>
        <Text>Upload File</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={handleDocumentPick}>
        <Text>Upload Document</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={handleVideoPick}>
        <Text>Upload Video</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={handleMusicPick}>
        <Text>Upload Music</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={handlePickImages}>
        <Text>Upload Images</Text>
      </TouchableOpacity>

      {/* Preview Buttons */}
      <TouchableOpacity onPress={() => showPreview('file')}>
        <Text>Preview Files</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={() => showPreview('video')}>
        <Text>Preview Videos</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={() => showPreview('music')}>
        <Text>Preview Music</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={() => showPreview('images')}>
        <Text>Preview Images</Text>
      </TouchableOpacity>

      {/* Preview Modal */}
      <Modal
        visible={isPreviewVisible}
        animationType="slide"
        transparent={true}
        onRequestClose={() => setPreviewVisible(false)}
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <Text>Preview {previewCategory}</Text>

            {/* Preview the files or images */}
            {previewCategory === 'file' && fileName ? <Text>{fileName}</Text> : null}
            {previewCategory === 'video' && videoName ? <Text>{videoName}</Text> : null}
            {previewCategory === 'music' && musicName ? <Text>{musicName}</Text> : null}
            {previewCategory === 'images' && imageUris.length > 0 ? (
              imageUris.map((uri, index) => (
                <Text key={index}>{uri}</Text>
              ))
            ) : null}

            <TouchableOpacity style={styles.clearButton} onPress={clearFiles}>
              <Text>Clear {previewCategory}</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.closeButton} onPress={() => setPreviewVisible(false)}>
              <Text>Close</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.5)',
  },
  modalContent: {
    width: '80%',
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 10,
    alignItems: 'center',
  },
  clearButton: {
    backgroundColor: 'red',
    padding: 10,
    borderRadius: 5,
    marginTop: 10,
  },
  closeButton: {
    backgroundColor: 'blue',
    padding: 10,
    borderRadius: 5,
    marginTop: 10,
  },
});

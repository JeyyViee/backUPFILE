import React, { useState, useEffect } from 'react';
import { View, Text, FlatList, StyleSheet, TouchableOpacity, Image } from 'react-native';
import { firebase } from '../firebaseUserConfig';
import { collection, onSnapshot } from 'firebase/firestore'; // Import onSnapshot for real-time updates
import { format } from 'date-fns'; // To format the date
import { Picker } from '@react-native-picker/picker';
import { getAuth } from 'firebase/auth'; // To get the current user

const SellerPosting = ({ navigation }) => {
  const [products, setProducts] = useState([]);
  const [category, setCategory] = useState('Default');
  const [sortBy, setSortBy] = useState('date');
  const user = getAuth().currentUser; // Get the current user

  // Setup listener for products from Firestore
  useEffect(() => {
    const unsubscribe = onSnapshot(collection(firebase.firestore(), 'products_services'), (querySnapshot) => {
      const fetchedProducts = querySnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data(),
      }));
      setProducts(fetchedProducts);
    }, (error) => {
      console.error('Error fetching products: ', error);
    });

    // Cleanup listener on unmount
    return () => unsubscribe();
  }, []);

  const formatDate = (createdAt) => {
    try {
      if (!createdAt) return 'Unknown Date';

      // Check if createdAt is a Firestore Timestamp and convert to JS Date
      const date = createdAt.seconds ? new Date(createdAt.seconds * 1000) : new Date(createdAt);

      return format(date, 'dd/MM/yyyy HH:mm');
    } catch (error) {
      return 'Unknown Date'; // Fallback in case of an error
    }
  };

  // Filter products based on the selected category
  const filterByCategory = (products) => {
    switch (category) {
      case 'Recent':
        return products.sort((a, b) => b.createdAt.seconds - a.createdAt.seconds);
      default:
        return products;
    }
  };

  // Sort products based on the selected option
  const sortProducts = (products) => {
    switch (sortBy) {
      case 'price':
        return products.sort((a, b) => a.price - b.price);
      case 'name':
        return products.sort((a, b) => a.name.localeCompare(b.name));
      case 'type':
        return products.sort((a, b) => a.type.localeCompare(b.type));
      default:
        return products.sort((a, b) => b.createdAt.seconds - a.createdAt.seconds);
    }
  };

  // Combine filtering and sorting
  const displayedProducts = sortProducts(filterByCategory(products));

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Products/Services</Text>

      {/* Category Selection */}
      <View style={styles.categoryContainer}>
        <TouchableOpacity onPress={() => setCategory('Recent')} style={category === 'Recent' ? styles.activeCategoryButton : styles.categoryButton}>
          <Text style={styles.categoryText}>Recent</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => setCategory('Default')} style={category === 'Default' ? styles.activeCategoryButton : styles.categoryButton}>
          <Text style={styles.categoryText}>Default</Text>
        </TouchableOpacity>
      </View>

      {/* Sort By Dropdown */}
      <Picker
        selectedValue={sortBy}
        style={styles.sortPicker}
        onValueChange={(itemValue) => setSortBy(itemValue)}
      >
        <Picker.Item label="Sort by Date" value="date" />
        <Picker.Item label="Sort by Name" value="name" />
        <Picker.Item label="Sort by Type" value="type" />
        <Picker.Item label="Sort by Price" value="price" />
      </Picker>

      {displayedProducts.length === 0 ? (
        <Text>No products/services available.</Text>
      ) : (
        <FlatList
          data={displayedProducts}
          keyExtractor={item => item.id}
          renderItem={({ item }) => (
            <TouchableOpacity
              onPress={() => navigation.navigate('ProductDetail', { product: item })} // Navigate with product data
              style={styles.productContainer}
            >
              {item.imageUrl && (
                <Image
                  source={{ uri: item.imageUrl }}
                  style={styles.productImage} // Style for the image
                />
              )}
              <Text style={styles.productText}>Name: {item.name}</Text>
              <Text style={styles.productText}>Price: ${item.price / 100}</Text>
              <Text style={styles.productText}>Seller: {item.sellerName}</Text>
              <Text style={styles.productText}>
                Created On: {formatDate(item.createdAt)}
              </Text>
            </TouchableOpacity>
          )}
        />
      )}

      {/* Button to navigate to the ServiceProduct.js screen */}
      <TouchableOpacity
        onPress={() => navigation.navigate('ServiceProduct')}
        style={styles.addButton}
      >
        <Text style={styles.addButtonText}>Add New Product/Service</Text>
      </TouchableOpacity>

      <TouchableOpacity
        onPress={() => navigation.navigate('ServiceProductCreation')} // Updated navigation
        style={styles.addButton}
      >
        <Text style={styles.addButtonText}>View Your Created Products/Services</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  categoryContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginBottom: 20,
  },
  categoryButton: {
    padding: 10,
    backgroundColor: '#f0f0f0',
    borderRadius: 5,
  },
  activeCategoryButton: {
    padding: 10,
    backgroundColor: '#4CAF50',
    borderRadius: 5,
  },
  categoryText: {
    fontWeight: 'bold',
  },
  sortPicker: {
    height: 50,
    width: '100%',
    marginBottom: 20,
  },
  productContainer: {
    padding: 15,
    borderBottomColor: '#ccc',
    borderBottomWidth: 1,
    marginBottom: 10, // Add some space between items
  },
  productText: {
    fontSize: 16,
  },
  productImage: {
    width: '100%', // Image will span the full width of the container
    height: 150,   // Set a fixed height for the image
    resizeMode: 'cover', // Ensure the image is nicely scaled
    marginBottom: 10, // Add space between the image and text
    borderRadius: 8,  // Add some rounding to the image corners
  },
  addButton: {
    backgroundColor: '#4CAF50',
    padding: 15,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 20,
  },
  addButtonText: {
    color: 'white',
    fontWeight: 'bold',
  },
});

export default SellerPosting;

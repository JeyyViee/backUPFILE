import React, { useState, useEffect, useCallback } from 'react';
import { Alert } from 'react-native'; // Import Alert for user notifications
import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs'; 
import { Ionicons } from '@expo/vector-icons'; 
import { firebase } from "./firebaseUserConfig";

import Login from "./src/Login";
import Registration from "./src/Registration";
import Dashboard from "./src/Dashboard"; // Client Dashboard
import Shopping from "./src/Shopping"; 
import SettingsScreen from "./src/Settings"; 
import Message from "./src/Message"; 
import SellerD from './seller/SellerD'; // Seller Dashboard

const Stack = createStackNavigator();
const Tab = createBottomTabNavigator();

// Bottom tab navigator setup for Clients
function ClientTabs() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarIcon: ({ color, size }) => {
          let iconName;
          switch (route.name) {
            case 'Dashboard':
              iconName = 'person';
              break;
            case 'Shopping':
              iconName = 'bag-add';
              break;
            case 'Settings':
              iconName = 'options';
              break;
            case 'Message':
              iconName = 'chatbubbles';
              break;
            default:
              iconName = 'ios-home';
          }
          return <Ionicons name={iconName} size={size} color={color} />;
        },
        tabBarActiveTintColor: '#E6E6FA',
        tabBarInactiveTintColor: 'purple',
      })}
    >
      <Tab.Screen name="Shopping" component={Shopping} />
      <Tab.Screen name="Message" component={Message} />
      <Tab.Screen name="Dashboard" component={Dashboard} />
      <Tab.Screen name="Settings" component={SettingsScreen} />
    </Tab.Navigator>
  );
}

// Bottom tab navigator setup for Sellers
function SellerTabs() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarIcon: ({ color, size }) => {
          let iconName;
          switch (route.name) {
            case 'Seller Dashboard':
              iconName = 'person';
              break;
            case 'Shopping':
              iconName = 'bag-add';
              break;
            case 'Settings':
              iconName = 'options';
              break;
            case 'Message':
              iconName = 'chatbubbles';
              break;
            default:
              iconName = 'ios-home';
          }
          return <Ionicons name={iconName} size={size} color={color} />;
        },
        tabBarActiveTintColor: '#E6E6FA',
        tabBarInactiveTintColor: 'purple',
      })}
    >
      <Tab.Screen name="Shopping" component={Shopping} />
      <Tab.Screen name="Message" component={Message} />
      <Tab.Screen name="Seller Dashboard" component={SellerD} />
      <Tab.Screen name="Settings" component={SettingsScreen} />
    </Tab.Navigator>
  );
}

function App() {
  const [initializing, setInitializing] = useState(true);
  const [user, setUser] = useState(null);
  const [userRole, setUserRole] = useState(null); // Store the role (Client/Seller)

  const onAuthStateChanged = useCallback(async (user) => {
    setUser(user);
    if (user) {
      const userDoc = await firebase.firestore().collection('users').doc(user.uid).get();
      if (userDoc.exists) {
        setUserRole(userDoc.data().role); // Set user role
        
        // Check if email is verified
        if (!user.emailVerified) {
          Alert.alert('Error', 'Please verify your email before logging in.');
          firebase.auth().signOut(); // Sign out unverified user
          setUser(null); // Clear user state
          setUserRole(null); // Clear role state
          return;
        }
      } else {
        setUserRole(null); // Handle case where user does not have a role
      }
    }
    if (initializing) setInitializing(false);
  }, [initializing]);

  useEffect(() => {
    const subscriber = firebase.auth().onAuthStateChanged(onAuthStateChanged);
    return () => subscriber();
  }, [onAuthStateChanged]);

  if (initializing) return null;

  // Show login and registration if not logged in
  if (!user) {
    return (
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        <Stack.Screen name="Login" component={Login} />
        <Stack.Screen name="Registration" component={Registration} />
      </Stack.Navigator>
    );
  }

  // Redirect based on role
  if (userRole === 'Seller') {
    return <SellerTabs />; // Use SellerTabs for seller navigation
  }

  return <ClientTabs />; // Use ClientTabs for client navigation
}

export default () => (
  <NavigationContainer>
    <App />
  </NavigationContainer>
);

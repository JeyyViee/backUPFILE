// Seller.js
import React, { useState, useEffect, useCallback } from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { View, Text, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons'; 
import { firebase } from "../firebaseUserConfig";

import Dashboard from "../src/Dashboard";
import Shopping from "../src/Shopping"; 
import SettingsScreen from "../src/Settings"; 
import Message from "../src/Message"; 

const Tab = createBottomTabNavigator();

const Seller = () => {
  const [initializing, setInitializing] = useState(true);
  const [user, setUser] = useState(null);

  const onAuthStateChanged = useCallback((user) => {
    setUser(user);
    if (initializing) setInitializing(false);
  }, [initializing]);

  useEffect(() => {
    const subscriber = firebase.auth().onAuthStateChanged(onAuthStateChanged);
    return () => subscriber();
  }, [onAuthStateChanged]);

  if (initializing) return null;

  // If user is not logged in, you can return a simple message or navigate to the login screen
  if (!user) {
    return (
      <View style={styles.container}>
        <Text style={styles.title}>Please log in to access the seller dashboard.</Text>
      </View>
    );
  }

  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarIcon: ({ color, size }) => {
          let iconName;
          switch (route.name) {
            case 'Dashboard':
              iconName = 'person'; // Assuming this is a valid Ionicons name
              break;
            case 'Shopping':
              iconName = 'bag-add'; // Assuming this is a valid Ionicons name
              break;
            case 'Settings':
              iconName = 'options'; // Assuming this is a valid Ionicons name
              break;
            case 'Message':
              iconName = 'chatbubbles'; // Assuming this is a valid Ionicons name
              break;
            default:
              iconName = 'ios-home';
          }
          return <Ionicons name={iconName} size={size} color={color} />;
        },
        tabBarActiveTintColor: '#E6E6FA',
        tabBarInactiveTintColor: 'purple',
      })}>
      <Tab.Screen name="Dashboard" component={Dashboard} />
      <Tab.Screen name="Shopping" component={Shopping} />
      <Tab.Screen name="Settings" component={SettingsScreen} />
      <Tab.Screen name="Message" component={Message} />
    </Tab.Navigator>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#E6E6FA', // Light purple background
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#8A2BE2', // Violet text
  },
});

export default Seller;

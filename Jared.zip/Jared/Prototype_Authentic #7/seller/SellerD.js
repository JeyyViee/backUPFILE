import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

const SellerD = () => {
    return (
        <View style={styles.container}>
            <Text style={styles.title}>Welcome to the Seller Dashboard</Text>
            {/* Your seller functionalities go here */}
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#E6E6FA', // Light purple background
    },
    title: {
        fontSize: 24,
        fontWeight: 'bold',
        color: '#8A2BE2', // Violet text
    },
});

export default SellerD;
